<?php

namespace App\Controller;

use App\Entity\Task;
use App\Repository\TaskRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;



class GorevController extends AbstractController
{
    private TaskRepository $taskRepository;

    public function __construct(TaskRepository $taskRepository)
    {
        $this->taskRepository = $taskRepository;
    }

    #[Route('/gorev', name: 'app_gorev')]
    public function index(): Response
    {
        $time = new \DateTime();
        dd($time->format('H:i:s  Y-m-d'));

        return $this->render('gorev/index.html.twig', [
            'controller_name' => 'GorevController',
        ]);
    }

    #[Route('/add', name: 'app_gorev')]
    public function dataAdd(Request $request): JsonResponse
    {
        $request = $request->toArray();
        $task = new Task();
        $time = new \DateTime();

        $task
            ->setTaskName($request['gorev'])
            ->setPersonelName($request['personel'])
            ->setPrice($request['fiyat'])
            ->setCreatedAt($time)

        ;

        $this->taskRepository->add($task,true);


        return new JsonResponse('Eklendi ürün id: ');

    }

    #[Route('/remove', name: 'app_gorev')]
    public function dataRemove(Request $request): JsonResponse
    {
        $request = $request->toArray();
        $task = new Task();
        $time = new \DateTime();

        $task
            ->setTaskName($request['gorev'])
            ->setPersonelName($request['personel'])
            ->setPrice($request['fiyat'])
            ->setCreatedAt($time)

        ;

        $this->taskRepository->add($task,true);


        return new JsonResponse('Eklendi ürün id: ');

    }


}
