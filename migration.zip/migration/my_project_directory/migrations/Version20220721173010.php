<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20220721173010 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE task ADD personel_name VARCHAR(255) NOT NULL, CHANGE price price DOUBLE PRECISION NOT NULL');
        $this->addSql('INSERT INTO task (task_name,created_at,price,personel_name) values ("Görev 1" ,"2022-07-21","100" ,"Fatma")');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE task DROP personel_name, CHANGE price price INT NOT NULL');
    }
}
