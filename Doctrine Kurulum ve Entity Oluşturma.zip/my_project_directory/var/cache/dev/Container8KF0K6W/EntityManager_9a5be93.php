<?php

namespace Container8KF0K6W;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolderd8143 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer8ce36 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties7cb73 = [
        
    ];

    public function getConnection()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'getConnection', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'getMetadataFactory', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'getExpressionBuilder', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'beginTransaction', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'getCache', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->getCache();
    }

    public function transactional($func)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'transactional', array('func' => $func), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'wrapInTransaction', array('func' => $func), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'commit', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->commit();
    }

    public function rollback()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'rollback', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'getClassMetadata', array('className' => $className), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'createQuery', array('dql' => $dql), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'createNamedQuery', array('name' => $name), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'createQueryBuilder', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'flush', array('entity' => $entity), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'clear', array('entityName' => $entityName), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->clear($entityName);
    }

    public function close()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'close', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->close();
    }

    public function persist($entity)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'persist', array('entity' => $entity), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'remove', array('entity' => $entity), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'refresh', array('entity' => $entity), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'detach', array('entity' => $entity), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'merge', array('entity' => $entity), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'getRepository', array('entityName' => $entityName), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'contains', array('entity' => $entity), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'getEventManager', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'getConfiguration', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'isOpen', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'getUnitOfWork', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'getProxyFactory', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'initializeObject', array('obj' => $obj), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'getFilters', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'isFiltersStateClean', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'hasFilters', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return $this->valueHolderd8143->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer8ce36 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolderd8143) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolderd8143 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolderd8143->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, '__get', ['name' => $name], $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        if (isset(self::$publicProperties7cb73[$name])) {
            return $this->valueHolderd8143->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderd8143;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderd8143;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderd8143;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderd8143;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, '__isset', array('name' => $name), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderd8143;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolderd8143;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, '__unset', array('name' => $name), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderd8143;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolderd8143;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, '__clone', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        $this->valueHolderd8143 = clone $this->valueHolderd8143;
    }

    public function __sleep()
    {
        $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, '__sleep', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;

        return array('valueHolderd8143');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer8ce36 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer8ce36;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer8ce36 && ($this->initializer8ce36->__invoke($valueHolderd8143, $this, 'initializeProxy', array(), $this->initializer8ce36) || 1) && $this->valueHolderd8143 = $valueHolderd8143;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolderd8143;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolderd8143;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
